import { NgModule } from '@angular/core';
import { CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';

@NgModule({
    declarations: [],
	schemas: [CUSTOM_ELEMENTS_SCHEMA],
	exports: []
})

export class ElementModule { }
