<?php
# FileName="connect.php"
$hostname = "";
$database = "";
$username = "";
$hostname = "";
$username = "";
$dbname = "";
$password = "";
?>